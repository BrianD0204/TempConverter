package com.example.tempconverter

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var temperatureInput: EditText
    private lateinit var convertButton: Button
    private lateinit var resultTextView: TextView
    private lateinit var fahrenheitToCelsius: RadioButton
    private lateinit var celsiusToFahrenheit: RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        temperatureInput = findViewById(R.id.temperatureInput)
        convertButton = findViewById(R.id.convertButton)
        resultTextView = findViewById(R.id.resultTextView)
        fahrenheitToCelsius = findViewById(R.id.fahrenheitToCelsius)
        celsiusToFahrenheit = findViewById(R.id.celsiusToFahrenheit)

        convertButton.setOnClickListener {
            convertTemperature()
        }
    }

    private fun convertTemperature() {
        val temperatureText = temperatureInput.text.toString()
        if (temperatureText.isEmpty()) {
            resultTextView.text = "Please enter a temperature"
            return
        }

        val temperature = temperatureText.toDouble()

        val convertedTemperature: Double = if (fahrenheitToCelsius.isChecked) {
            (temperature - 32.0) * 5.0 / 9.0
        } else {
            (temperature * 9.0 / 5.0) + 32.0
        }

        val conversionType = if (fahrenheitToCelsius.isChecked) "F to C" else "C to F"
        val resultString = String.format("%.1f", convertedTemperature)
        val historyEntry = "$conversionType: $temperatureText -> $resultString"

        val currentText = resultTextView.text.toString()
        val newText = if (currentText.isEmpty()) {
            historyEntry
        } else {
            currentText + "\n" + historyEntry
        }

        resultTextView.text = newText
    }

}
